using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Folha_de_Pagamento
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }


        // conexao com  o banco de dados sql serve
        SqlConnection cn = new SqlConnection(@"Data Source= LAPTOP-AB691TNN\SQL;integrated security=SSPI;initial Catalog=FolhaDePagamento");

        SqlCommand cm = new SqlCommand();

        SqlDataReader dt;


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnSenha_MouseDown(object sender, MouseEventArgs e)
        {
            txtSenha.UseSystemPasswordChar = false;
        }

        private void btnSenha_MouseUp(object sender, MouseEventArgs e)
        {
            txtSenha.UseSystemPasswordChar = true;
        }

        private void btnAcessar_Click(object sender, EventArgs e)
        {

        }

        private void btnAcessar_Click_1(object sender, EventArgs e)
        {
            if (txtLogin.Text == "" || txtSenha.Text == "")
            {
                MessageBox.Show("obrigat�rio preencher os campos logim e senha", "Aten��o!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            else
            {
                try
                {
                    cn.Open();
                    cm.CommandText = "select * from Usuarios where username = ( '" + txtLogin.Text + "') and password =('" + txtSenha.Text + "') and ds_status = 1";
                    cm.Connection = cn;
                    dt = cm.ExecuteReader();

                    if (dt.HasRows)
                    {
                        FrmMenu menu = new FrmMenu();
                        menu.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Usu�rio ou senha imv�lidos", "Ocorreu um erro!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtLogin.Clear();
                        txtSenha.Clear();
                        txtLogin.Focus();
                    }
                }
                catch (Exception erro)
                {
                    MessageBox.Show(erro.Message);
                    cn.Close();
                }
                finally
                {
                    cn.Close();
                }
            }
        }

        private void txtLogin_TextChanged(object sender, EventArgs e)
        {

        }
    }
}