﻿namespace Folha_de_Pagamento
{
    partial class frmLogin
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            talaRoxa = new Panel();
            label4 = new Label();
            label2 = new Label();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            panel2 = new Panel();
            btnAcessar = new Button();
            panel4 = new Panel();
            panel5 = new Panel();
            txtSenha = new TextBox();
            btnSenha = new PictureBox();
            panel3 = new Panel();
            panel6 = new Panel();
            txtLogin = new TextBox();
            pictureBox2 = new PictureBox();
            label3 = new Label();
            btnFechar = new Button();
            talaRoxa.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)btnSenha).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // talaRoxa
            // 
            talaRoxa.BackColor = Color.Indigo;
            talaRoxa.Controls.Add(label4);
            talaRoxa.Controls.Add(label2);
            talaRoxa.Controls.Add(label1);
            talaRoxa.Controls.Add(pictureBox1);
            talaRoxa.Dock = DockStyle.Left;
            talaRoxa.Location = new Point(0, 0);
            talaRoxa.Margin = new Padding(3, 2, 3, 2);
            talaRoxa.Name = "talaRoxa";
            talaRoxa.Size = new Size(262, 398);
            talaRoxa.TabIndex = 0;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.White;
            label4.Location = new Point(40, 292);
            label4.Name = "label4";
            label4.Size = new Size(213, 22);
            label4.TabIndex = 4;
            label4.Text = "de Folha de Pagamento";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.White;
            label2.Location = new Point(60, 265);
            label2.Name = "label2";
            label2.Size = new Size(189, 22);
            label2.TabIndex = 2;
            label2.Text = "Sistema Gerenciador";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(113, 236);
            label1.Name = "label1";
            label1.Size = new Size(140, 22);
            label1.TabIndex = 1;
            label1.Text = "Bem Vindos ao";
            label1.Click += label1_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.GADE_BRANCO_70;
            pictureBox1.Location = new Point(3, 0);
            pictureBox1.Margin = new Padding(3, 2, 3, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(259, 106);
            pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            panel2.Controls.Add(btnAcessar);
            panel2.Controls.Add(panel4);
            panel2.Controls.Add(panel3);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(btnFechar);
            panel2.Dock = DockStyle.Fill;
            panel2.Location = new Point(262, 0);
            panel2.Margin = new Padding(3, 2, 3, 2);
            panel2.Name = "panel2";
            panel2.Size = new Size(394, 398);
            panel2.TabIndex = 1;
            panel2.Paint += panel2_Paint;
            // 
            // btnAcessar
            // 
            btnAcessar.BackColor = Color.Indigo;
            btnAcessar.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            btnAcessar.ForeColor = Color.White;
            btnAcessar.ImageAlign = ContentAlignment.MiddleLeft;
            btnAcessar.Location = new Point(276, 220);
            btnAcessar.Margin = new Padding(3, 2, 3, 2);
            btnAcessar.Name = "btnAcessar";
            btnAcessar.Size = new Size(116, 40);
            btnAcessar.TabIndex = 5;
            btnAcessar.Text = "Acessar";
            btnAcessar.UseVisualStyleBackColor = false;
            btnAcessar.Click += btnAcessar_Click_1;
            // 
            // panel4
            // 
            panel4.BackColor = SystemColors.Window;
            panel4.Controls.Add(panel5);
            panel4.Controls.Add(txtSenha);
            panel4.Controls.Add(btnSenha);
            panel4.Location = new Point(0, 182);
            panel4.Margin = new Padding(3, 2, 3, 2);
            panel4.Name = "panel4";
            panel4.Size = new Size(394, 34);
            panel4.TabIndex = 4;
            panel4.Paint += panel4_Paint;
            // 
            // panel5
            // 
            panel5.BackColor = Color.Black;
            panel5.Location = new Point(43, 31);
            panel5.Margin = new Padding(3, 2, 3, 2);
            panel5.Name = "panel5";
            panel5.Size = new Size(348, 1);
            panel5.TabIndex = 6;
            // 
            // txtSenha
            // 
            txtSenha.BorderStyle = BorderStyle.None;
            txtSenha.Font = new Font("Arial Narrow", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtSenha.Location = new Point(43, 3);
            txtSenha.Margin = new Padding(3, 2, 3, 2);
            txtSenha.MaxLength = 15;
            txtSenha.Name = "txtSenha";
            txtSenha.Size = new Size(348, 25);
            txtSenha.TabIndex = 7;
            txtSenha.UseSystemPasswordChar = true;
            // 
            // btnSenha
            // 
            btnSenha.Image = Properties.Resources.padlock_security_password_icon_193552;
            btnSenha.Location = new Point(3, 4);
            btnSenha.Margin = new Padding(3, 2, 3, 2);
            btnSenha.Name = "btnSenha";
            btnSenha.Size = new Size(35, 30);
            btnSenha.SizeMode = PictureBoxSizeMode.StretchImage;
            btnSenha.TabIndex = 6;
            btnSenha.TabStop = false;
            btnSenha.MouseDown += btnSenha_MouseDown;
            btnSenha.MouseUp += btnSenha_MouseUp;
            // 
            // panel3
            // 
            panel3.BackColor = SystemColors.Window;
            panel3.Controls.Add(panel6);
            panel3.Controls.Add(txtLogin);
            panel3.Controls.Add(pictureBox2);
            panel3.Location = new Point(0, 144);
            panel3.Margin = new Padding(3, 2, 3, 2);
            panel3.Name = "panel3";
            panel3.Size = new Size(394, 34);
            panel3.TabIndex = 3;
            // 
            // panel6
            // 
            panel6.BackColor = Color.Black;
            panel6.Location = new Point(46, 29);
            panel6.Margin = new Padding(3, 2, 3, 2);
            panel6.Name = "panel6";
            panel6.Size = new Size(348, 1);
            panel6.TabIndex = 7;
            // 
            // txtLogin
            // 
            txtLogin.BorderStyle = BorderStyle.None;
            txtLogin.Font = new Font("Arial Narrow", 16.2F, FontStyle.Regular, GraphicsUnit.Point);
            txtLogin.Location = new Point(43, 4);
            txtLogin.Margin = new Padding(3, 2, 3, 2);
            txtLogin.MaxLength = 20;
            txtLogin.Name = "txtLogin";
            txtLogin.Size = new Size(348, 25);
            txtLogin.TabIndex = 6;
            txtLogin.TextChanged += txtLogin_TextChanged;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.do_utilizador__1_;
            pictureBox2.Location = new Point(5, 2);
            pictureBox2.Margin = new Padding(3, 2, 3, 2);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(35, 30);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 5;
            pictureBox2.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.Indigo;
            label3.Location = new Point(0, 116);
            label3.Name = "label3";
            label3.Size = new Size(133, 22);
            label3.TabIndex = 2;
            label3.Text = "Faça seu login";
            // 
            // btnFechar
            // 
            btnFechar.FlatAppearance.BorderSize = 0;
            btnFechar.FlatStyle = FlatStyle.Flat;
            btnFechar.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            btnFechar.ForeColor = Color.Indigo;
            btnFechar.Location = new Point(359, 0);
            btnFechar.Margin = new Padding(3, 2, 3, 2);
            btnFechar.Name = "btnFechar";
            btnFechar.Size = new Size(35, 30);
            btnFechar.TabIndex = 0;
            btnFechar.Text = "X";
            btnFechar.UseVisualStyleBackColor = true;
            btnFechar.Click += btnFechar_Click;
            // 
            // frmLogin
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            AutoSize = true;
            ClientSize = new Size(656, 398);
            Controls.Add(panel2);
            Controls.Add(talaRoxa);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 2, 3, 2);
            Name = "frmLogin";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            talaRoxa.ResumeLayout(false);
            talaRoxa.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)btnSenha).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel talaRoxa;
        private Panel panel2;
        private Label label1;
        private PictureBox pictureBox1;
        private Label label2;
        private Label label4;
        private Button btnFechar;
        private Label label3;
        private Panel panel4;
        private Panel panel3;
        private PictureBox btnSenha;
        private PictureBox pictureBox2;
        private TextBox txtLogin;
        private TextBox txtSenha;
        private Button btnAcessar;
        private Panel panel5;
        private Panel panel6;
    }
}