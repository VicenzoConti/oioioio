﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Folha_de_Pagamento
{
    public partial class FrmMenu : Form
    {
        public FrmMenu()
        {
            InitializeComponent();
        }

        private void btnFunc_Click(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {

            frmLogin login = new frmLogin();
            login.Show();
            this.Hide();
        }

        private void FrmMenu_Load(object sender, EventArgs e)
        {
        }

        private void btnLista_Click(object sender, EventArgs e)
        {

        }

        private void principal2_Load(object sender, EventArgs e)
        {

        }

        private void frmFuncionario1_Load(object sender, EventArgs e)
        {

        }
    }
}
