﻿namespace Folha_de_Pagamento
{
    partial class FrmMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pneMenu = new Panel();
            btnSair = new Button();
            btnBenrficios = new Button();
            btnImpostos = new Button();
            btnExtrato = new Button();
            btnLista = new Button();
            btnFunc = new Button();
            pneLog = new Panel();
            pictureBox1 = new PictureBox();
            principal1 = new principal();
            frmFuncionario2 = new frmFuncionario();
            pneMenu.SuspendLayout();
            pneLog.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pneMenu
            // 
            pneMenu.BackColor = Color.Indigo;
            pneMenu.Controls.Add(btnSair);
            pneMenu.Controls.Add(btnBenrficios);
            pneMenu.Controls.Add(btnImpostos);
            pneMenu.Controls.Add(btnExtrato);
            pneMenu.Controls.Add(btnLista);
            pneMenu.Controls.Add(btnFunc);
            pneMenu.Controls.Add(pneLog);
            pneMenu.Dock = DockStyle.Left;
            pneMenu.Location = new Point(0, 0);
            pneMenu.Margin = new Padding(3, 2, 3, 2);
            pneMenu.Name = "pneMenu";
            pneMenu.Size = new Size(192, 765);
            pneMenu.TabIndex = 0;
            // 
            // btnSair
            // 
            btnSair.Dock = DockStyle.Top;
            btnSair.FlatAppearance.BorderSize = 0;
            btnSair.FlatStyle = FlatStyle.Flat;
            btnSair.Font = new Font("Arial Narrow", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnSair.ForeColor = SystemColors.ButtonFace;
            btnSair.Image = Properties.Resources.saida__1_;
            btnSair.ImageAlign = ContentAlignment.MiddleLeft;
            btnSair.Location = new Point(0, 279);
            btnSair.Margin = new Padding(3, 2, 3, 2);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(192, 40);
            btnSair.TabIndex = 6;
            btnSair.Text = " Sair";
            btnSair.TextAlign = ContentAlignment.MiddleLeft;
            btnSair.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnSair.UseVisualStyleBackColor = true;
            btnSair.Click += btnSair_Click;
            // 
            // btnBenrficios
            // 
            btnBenrficios.Dock = DockStyle.Top;
            btnBenrficios.FlatAppearance.BorderSize = 0;
            btnBenrficios.FlatStyle = FlatStyle.Flat;
            btnBenrficios.Font = new Font("Arial Narrow", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnBenrficios.ForeColor = SystemColors.ButtonFace;
            btnBenrficios.Image = Properties.Resources.dolar_cracha;
            btnBenrficios.ImageAlign = ContentAlignment.MiddleLeft;
            btnBenrficios.Location = new Point(0, 239);
            btnBenrficios.Margin = new Padding(3, 2, 3, 2);
            btnBenrficios.Name = "btnBenrficios";
            btnBenrficios.Size = new Size(192, 40);
            btnBenrficios.TabIndex = 5;
            btnBenrficios.Text = " Beneficios";
            btnBenrficios.TextAlign = ContentAlignment.MiddleLeft;
            btnBenrficios.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnBenrficios.UseVisualStyleBackColor = true;
            // 
            // btnImpostos
            // 
            btnImpostos.Dock = DockStyle.Top;
            btnImpostos.FlatAppearance.BorderSize = 0;
            btnImpostos.FlatStyle = FlatStyle.Flat;
            btnImpostos.Font = new Font("Arial Narrow", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnImpostos.ForeColor = SystemColors.ButtonFace;
            btnImpostos.Image = Properties.Resources.fatura_de_arquivo__2_;
            btnImpostos.ImageAlign = ContentAlignment.MiddleLeft;
            btnImpostos.Location = new Point(0, 199);
            btnImpostos.Margin = new Padding(3, 2, 3, 2);
            btnImpostos.Name = "btnImpostos";
            btnImpostos.Size = new Size(192, 40);
            btnImpostos.TabIndex = 4;
            btnImpostos.Text = " Impostos";
            btnImpostos.TextAlign = ContentAlignment.MiddleLeft;
            btnImpostos.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnImpostos.UseVisualStyleBackColor = true;
            // 
            // btnExtrato
            // 
            btnExtrato.Dock = DockStyle.Top;
            btnExtrato.FlatAppearance.BorderSize = 0;
            btnExtrato.FlatStyle = FlatStyle.Flat;
            btnExtrato.Font = new Font("Arial Narrow", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnExtrato.ForeColor = SystemColors.ButtonFace;
            btnExtrato.Image = Properties.Resources.dinheiro_cheque_editar;
            btnExtrato.ImageAlign = ContentAlignment.MiddleLeft;
            btnExtrato.Location = new Point(0, 159);
            btnExtrato.Margin = new Padding(3, 2, 3, 2);
            btnExtrato.Name = "btnExtrato";
            btnExtrato.Size = new Size(192, 40);
            btnExtrato.TabIndex = 3;
            btnExtrato.Text = " Extrato";
            btnExtrato.TextAlign = ContentAlignment.MiddleLeft;
            btnExtrato.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnExtrato.UseVisualStyleBackColor = true;
            // 
            // btnLista
            // 
            btnLista.Dock = DockStyle.Top;
            btnLista.FlatAppearance.BorderSize = 0;
            btnLista.FlatStyle = FlatStyle.Flat;
            btnLista.Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point);
            btnLista.ForeColor = SystemColors.ButtonFace;
            btnLista.Image = Properties.Resources.usuarios_alt;
            btnLista.ImageAlign = ContentAlignment.MiddleLeft;
            btnLista.Location = new Point(0, 119);
            btnLista.Margin = new Padding(3, 2, 3, 2);
            btnLista.Name = "btnLista";
            btnLista.Size = new Size(192, 40);
            btnLista.TabIndex = 2;
            btnLista.Text = " Lista Funcionario";
            btnLista.TextAlign = ContentAlignment.MiddleLeft;
            btnLista.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnLista.UseVisualStyleBackColor = true;
            btnLista.Click += btnLista_Click;
            // 
            // btnFunc
            // 
            btnFunc.Dock = DockStyle.Top;
            btnFunc.FlatAppearance.BorderSize = 0;
            btnFunc.FlatStyle = FlatStyle.Flat;
            btnFunc.Font = new Font("Arial Narrow", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            btnFunc.ForeColor = SystemColors.ButtonFace;
            btnFunc.Image = Properties.Resources.usuario_do_circulo;
            btnFunc.ImageAlign = ContentAlignment.MiddleLeft;
            btnFunc.Location = new Point(0, 79);
            btnFunc.Margin = new Padding(3, 2, 3, 2);
            btnFunc.Name = "btnFunc";
            btnFunc.Size = new Size(192, 40);
            btnFunc.TabIndex = 1;
            btnFunc.Text = " Funcionario";
            btnFunc.TextAlign = ContentAlignment.MiddleLeft;
            btnFunc.TextImageRelation = TextImageRelation.ImageBeforeText;
            btnFunc.UseVisualStyleBackColor = true;
            btnFunc.Click += btnFunc_Click;
            // 
            // pneLog
            // 
            pneLog.BackColor = Color.Black;
            pneLog.Controls.Add(pictureBox1);
            pneLog.Dock = DockStyle.Top;
            pneLog.Location = new Point(0, 0);
            pneLog.Margin = new Padding(3, 2, 3, 2);
            pneLog.Name = "pneLog";
            pneLog.Size = new Size(192, 79);
            pneLog.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Image = Properties.Resources.GADE_BRANCO_70;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Margin = new Padding(3, 2, 3, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(192, 79);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // principal1
            // 
            principal1.Location = new Point(194, 0);
            principal1.Margin = new Padding(3, 2, 3, 2);
            principal1.Name = "principal1";
            principal1.Size = new Size(982, 523);
            principal1.TabIndex = 1;
            // 
            // frmFuncionario2
            // 
            frmFuncionario2.Font = new Font("Arial Narrow", 9F, FontStyle.Regular, GraphicsUnit.Point);
            frmFuncionario2.Location = new Point(197, 0);
            frmFuncionario2.Margin = new Padding(3, 2, 3, 2);
            frmFuncionario2.Name = "frmFuncionario2";
            frmFuncionario2.Size = new Size(1129, 691);
            frmFuncionario2.TabIndex = 4;
            frmFuncionario2.UseWaitCursor = true;
            // 
            // FrmMenu
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1366, 765);
            Controls.Add(frmFuncionario2);
            Controls.Add(principal1);
            Controls.Add(pneMenu);
            Margin = new Padding(3, 2, 3, 2);
            Name = "FrmMenu";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "FrmMenu";
            Load += FrmMenu_Load;
            pneMenu.ResumeLayout(false);
            pneLog.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel pneMenu;
        private Panel pneLog;
        private Button btnFunc;
        private Button btnSair;
        private Button btnBenrficios;
        private Button btnImpostos;
        private Button btnExtrato;
        private Button btnLista;
        private principal principal1;
        private PictureBox pictureBox1;
        private frmFuncionario frmFuncionario2;
    }
}