﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Folha_de_Pagamento
{
    public partial class frmFuncionario : UserControl
    {
        public frmFuncionario()
        {
            InitializeComponent();
        }


        // conexao com  o banco de dados sql serve
        SqlConnection cn = new SqlConnection(@"Data Source= LAPTOP-AB691TNN\SQL;integrated security=SSPI;initial Catalog=FolhaDePagamento");

        SqlCommand cm = new SqlCommand();

        SqlDataReader dt;

        private void desabilitaCampos()
        {
            txtNome.Enabled = false;
            txtSobreNome.Enabled = false;
            txtTelefone.Enabled = false;
            txt_cargo.Enabled = false;
            txt_cpf.Enabled = false;
            txt_DataContrato.Enabled = false;
            txt_salario.Enabled = false;
            txtEmail.Enabled = false;
            txtEndereco.Enabled = false;
            txtGenero.Enabled = false;
            txtDataNacimento.Enabled = false;
            txtEstadoCivil.Enabled = false;
            txtDependentes.Enabled = false;
            txtDepartamento.Enabled = false;
            btnGravar.Enabled = false;
            btnAlterar.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = false;
            btnNovo.Enabled = true;
        }

        private void habilitaCampos()
        {
            txtNome.Enabled = true;
            btnGravar.Enabled = true;
            btnCancelar.Enabled = true;
            txtSobreNome.Enabled = true;
            txtTelefone.Enabled = true;
            txt_cargo.Enabled = true;
            txt_cpf.Enabled = true;
            txt_DataContrato.Enabled = true;
            txt_salario.Enabled = true;
            txtEmail.Enabled = true;
            txtEndereco.Enabled = true;
            txtGenero.Enabled = true;
            txtDataNacimento.Enabled = true;
            txtEstadoCivil.Enabled = true;
            txtDependentes.Enabled = true;
            txtDepartamento.Enabled = true;

            btnNovo.Enabled = false;
            txtNome.Focus();
            txtBusca.Text = "";
            dgvfunc.DataSource = null;

        }

        private void limparCampos()
        {
            txtNome.Clear();
            txtSobreNome.Clear();
            txtTelefone.Clear();
            txt_cargo.Clear();
            txt_cpf.Clear();
            txt_DataContrato.Clear();
            txt_salario.Clear();
            txtEmail.Clear();
            txtEndereco.Clear();
            txtGenero.Clear();
            txtDataNacimento.Clear();
            txtEstadoCivil.Clear();
            txtDependentes.Clear();
            txtDepartamento.Clear();
            txtNome.Focus();
            txtBusca.Clear();
            dgvfunc.DataSource = null;
            rdbAtivo.Checked = true;

        }

        private void manipularDados()
        {
            lbl_cod.Visible = true;
            lblCodigo.Visible = true;
            btnAlterar.Enabled = true;
            btnExcluir.Enabled = true;
            btnCancelar.Enabled = true;
            btnNovo.Enabled = false;
            btnGravar.Enabled = false;
            txtNome.Enabled = true;
            btnGravar.Enabled = true;
            btnCancelar.Enabled = true;
            txtSobreNome.Enabled = true;
            txtTelefone.Enabled = true;
            txt_cargo.Enabled = true;
            txt_cpf.Enabled = true;
            txt_DataContrato.Enabled = true;
            txt_salario.Enabled = true;
            txtEmail.Enabled = true;
            txtEndereco.Enabled = true;
            txtGenero.Enabled = true;
            txtDataNacimento.Enabled = true;
            txtEstadoCivil.Enabled = true;
            txtDependentes.Enabled = true;
            txtDepartamento.Enabled = true;

        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
        }



        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }



        private void frmFuncionario_Load(object sender, EventArgs e)
        {
            desabilitaCampos();
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            habilitaCampos();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            desabilitaCampos();
            limparCampos();
        }

        private void btnGravar_Click(object sender, EventArgs e)
        {
            if (txtNome.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo nome.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNome.Focus();
            }
            else if (txtSobreNome.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo sobre nomo.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSobreNome.Focus();
            }
            else if (txt_cpf.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo CPF.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_cpf.Focus();
            }
            else if (txt_cargo.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo cargo.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_cargo.Focus();
            }
            else if (txt_salario.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo salario.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_salario.Focus();
            }
            else if (txt_DataContrato.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo Data de Contrato.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_DataContrato.Focus();
            }
            else if (txtEndereco.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo Endereço.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEndereco.Focus();
            }
            else if (txtTelefone.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo Telefone.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtTelefone.Focus();
            }
            else if (txtEmail.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo Email.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEmail.Focus();
            }
            else if (txtGenero.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo Genero.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtGenero.Focus();
            }
            else if (txtDataNacimento.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo Data de nacimento.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDataNacimento.Focus();
            }
            else if (txtEstadoCivil.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo Estado civil.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEstadoCivil.Focus();
            }
            else if (txtDependentes.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo Dependesntes.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDependentes.Focus();
            }
            else if (txtDepartamento.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo Departamento.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDepartamento.Focus();
            }

            else
            {
                try
                {
                    string nome = txtNome.Text;
                    string sobrenome = txtSobreNome.Text;
                    string cpf = txt_cpf.Text;
                    string cargo = txt_cargo.Text;
                    string salariosalario_base = txt_salario.Text;
                    // DateTime data_contratacao = txt_DataContrato;
                    string endereco = txtEndereco.Text;
                    string telefone = txtTelefone.Text;
                    string email = txtEmail.Text;
                    string genero = txtGenero.Text;
                    //DateTime data_nascimento = txtDataNacimento;
                    string estado_civil = txtEstadoCivil.Text;
                    string numero_dependentes = txtDependentes.Text;
                    string departamento = txtDepartamento.Text;

                    string txtDataNascimento = "09-09-1990"; // Substitua pelo valor da sua variável
                    DateTime dataNascimento;

                    if (DateTime.TryParse(txtDataNascimento, out dataNascimento))
                    {
                        // A conversão foi bem-sucedida, e 'dataNascimento' contém a data de nascimento como DateTime.
                        Console.WriteLine("Data de nascimento: " + dataNascimento.ToString("MM/dd/yyyy"));
                    }
                    else
                    {
                        // A conversão falhou, informe ao usuário que a data é inválida.
                        Console.WriteLine("Data de nascimento inválida. Certifique-se de usar o formato yyyy-MM-dd.");
                    }

                    string dataContratoString = "1990-09-09"; // Suponhamos que 'txt_DataContrato' seja um TextBox onde o usuário inseriu a data como string
                    DateTime dataContratacao;

                    if (DateTime.TryParse(dataContratoString, out dataContratacao))
                    {
                        // A conversão foi bem-sucedida, e 'dataContratacao' contém a data inserida no TextBox.
                        Console.WriteLine("Data de contratação: " + dataContratacao.ToString("MM/dd/yyyy"));
                    }
                    else
                    {
                        // A conversão falhou, informe ao usuário que a data é inválida.
                        Console.WriteLine("Data de contratação inválida. Certifique-se de usar o formato yyyy-MM-dd.");
                    }


                    string strSql = "insert into Funcionarios(nome, sobrenome, cpf, cargo, salario_base, data_contratacao, endereco, telefone, email, genero, data_nascimento, estado_civil, numero_dependentes, departamento)values(@nome, @sobrenome, @cpf, @cargo, @salario_base, @dataContratacao, @endereco, @telefone, @email, @genero, @dataNascimento, @estado_civil, @numero_dependentes, @departamento)";

                    cm.CommandText = strSql;
                    cm.Connection = cn;


                    cm.Parameters.Add("@nome", SqlDbType.VarChar).Value = nome;
                    cm.Parameters.Add("@sobrenome", SqlDbType.VarChar).Value = sobrenome;
                    cm.Parameters.Add("@cpf", SqlDbType.VarChar).Value = cpf;
                    cm.Parameters.Add("@cargo", SqlDbType.VarChar).Value = cargo;
                    cm.Parameters.Add("@salario_base", SqlDbType.Decimal).Value = salariosalario_base;
                    cm.Parameters.Add("@dataContratacao", SqlDbType.Date).Value = dataContratacao;
                    cm.Parameters.Add("@endereco", SqlDbType.VarChar).Value = endereco;
                    cm.Parameters.Add("@telefone", SqlDbType.VarChar).Value = telefone;
                    cm.Parameters.Add("@email", SqlDbType.VarChar).Value = email;
                    cm.Parameters.Add("@genero", SqlDbType.Char).Value = genero;
                    cm.Parameters.Add("@dataNascimento", SqlDbType.Date).Value = dataNascimento;
                    cm.Parameters.Add("@estado_civil", SqlDbType.VarChar).Value = estado_civil;
                    cm.Parameters.Add("@numero_dependentes", SqlDbType.Int).Value = numero_dependentes;
                    cm.Parameters.Add("@departamento", SqlDbType.VarChar).Value = departamento;


                    cn.Open();
                    cm.ExecuteNonQuery();
                    cm.Parameters.Clear();
                    MessageBox.Show("os dados foram gravados com sucesso !!!.", "inserção de dados concluida", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtNome.Focus();
                    limparCampos();
                }
                catch (Exception errro)
                {
                    MessageBox.Show(errro.Message);
                    cn.Close();
                }

                finally
                {
                    cn.Close();
                }




            }

        }

        private void txtBusca_TextChanged(object sender, EventArgs e)
        {
            if (txtBusca.Text != "")
            {
                try
                {
                    cn.Open();
                    cm.CommandText = "select * from Funcionarios where nome like('" + txtBusca.Text + "%')";
                    cm.Connection = cn;


                    //recebe os dados de uma tabela após a execução de um Select
                    SqlDataAdapter da = new SqlDataAdapter();

                    // objeto DataTable pode repesentar uma ou mais tabelas de dados, as quais permanecem alocadas em memoria
                    DataTable dt = new DataTable();

                    // recebendo os dados da instrução select
                    da.SelectCommand = cm;
                    da.Fill(dt); // preenchendo o datatable
                    dgvfunc.DataSource = dt;
                    cn.Close();




                }
                catch (Exception erro)
                {
                    MessageBox.Show(erro.Message);
                }



            }
            else
            {
                dgvfunc.DataSource = null;
            }
        }

        private void caregaFuncionario()
        {
            lbl_cod.Text = dgvfunc.SelectedRows[0].Cells[0].Value.ToString();
            txtNome.Text = dgvfunc.SelectedRows[0].Cells[1].Value.ToString();
            txtSobreNome.Text = dgvfunc.SelectedRows[0].Cells[2].Value.ToString();
            txt_cpf.Text = dgvfunc.SelectedRows[0].Cells[3].Value.ToString();
            txt_cargo.Text = dgvfunc.SelectedRows[0].Cells[4].Value.ToString();
            txt_salario.Text = dgvfunc.SelectedRows[0].Cells[5].Value.ToString();
            txt_DataContrato.Text = dgvfunc.SelectedRows[0].Cells[6].Value.ToString();
            txtEndereco.Text = dgvfunc.SelectedRows[0].Cells[7].Value.ToString();
            txtTelefone.Text = dgvfunc.SelectedRows[0].Cells[8].Value.ToString();
            txtEmail.Text = dgvfunc.SelectedRows[0].Cells[9].Value.ToString();
            txtGenero.Text = dgvfunc.SelectedRows[0].Cells[10].Value.ToString();
            txtDataNacimento.Text = dgvfunc.SelectedRows[0].Cells[11].Value.ToString();
            txtEstadoCivil.Text = dgvfunc.SelectedRows[0].Cells[12].Value.ToString();
            txtDependentes.Text = dgvfunc.SelectedRows[0].Cells[13].Value.ToString();
            txtDepartamento.Text = dgvfunc.SelectedRows[0].Cells[14].Value.ToString();
            string valor = dgvfunc.SelectedRows[0].Cells[15].Value.ToString();
            //MessageBox.Show(valor);

            if(valor == "True")
            {
                rdbAtivo.Checked = true;

            }
            else
            {
                rdbInativo.Checked = true;
            }

            manipularDados();

        }
        private void dgvfunc_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            caregaFuncionario();

            if(rdbAtivo.Checked ) 
            {
                btnExcluir.Enabled = true;
            }
            else
            {
                btnExcluir.Enabled = false;
            }
        }

        private void btnAlterar_Click(object sender, EventArgs e)
        {
            if (txtNome.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo nome.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNome.Focus();
            }
            else if (txtSobreNome.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo sobre nomo.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtSobreNome.Focus();
            }
            else if (txt_cpf.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo CPF.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_cpf.Focus();
            }
            else if (txt_cargo.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo cargo.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_cargo.Focus();
            }
            else if (txt_salario.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo salario.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_salario.Focus();
            }
            else if (txt_DataContrato.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo Data de Contrato.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txt_DataContrato.Focus();
            }
            else if (txtEndereco.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo Endereço.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEndereco.Focus();
            }
            else if (txtTelefone.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo Telefone.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtTelefone.Focus();
            }
            else if (txtEmail.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo Email.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEmail.Focus();
            }
            else if (txtGenero.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo Genero.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtGenero.Focus();
            }
            else if (txtDataNacimento.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo Data de nacimento.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDataNacimento.Focus();
            }
            else if (txtEstadoCivil.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo Estado civil.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtEstadoCivil.Focus();
            }
            else if (txtDependentes.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo Dependesntes.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDependentes.Focus();
            }
            else if (txtDepartamento.Text == "")
            {
                MessageBox.Show("Obrigatorio informar o campo Departamento.", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtDepartamento.Focus();
            }

            else
            {
                try
                {
                    string nome = txtNome.Text;
                    string sobrenome = txtSobreNome.Text;
                    string cpf = txt_cpf.Text;
                    string cargo = txt_cargo.Text;
                    string salariosalario_base = txt_salario.Text;
                    // DateTime data_contratacao = txt_DataContrato;
                    string endereco = txtEndereco.Text;
                    string telefone = txtTelefone.Text;
                    string email = txtEmail.Text;
                    string genero = txtGenero.Text;
                    //DateTime data_nascimento = txtDataNacimento;
                    string estado_civil = txtEstadoCivil.Text;
                    string numero_dependentes = txtDependentes.Text;
                    string departamento = txtDepartamento.Text;
                    int id = Convert.ToInt32(lbl_cod.Text);

                    string txtDataNascimento = "09-09-1990"; // Substitua pelo valor da sua variável
                    DateTime dataNascimento;

                    if (DateTime.TryParse(txtDataNascimento, out dataNascimento))
                    {
                        // A conversão foi bem-sucedida, e 'dataNascimento' contém a data de nascimento como DateTime.
                        Console.WriteLine("Data de nascimento: " + dataNascimento.ToString("MM/dd/yyyy"));
                    }
                    else
                    {
                        // A conversão falhou, informe ao usuário que a data é inválida.
                        Console.WriteLine("Data de nascimento inválida. Certifique-se de usar o formato yyyy-MM-dd.");
                    }

                    string dataContratoString = "2023-09-09"; // Suponhamos que 'txt_DataContrato' seja um TextBox onde o usuário inseriu a data como string
                    DateTime dataContratacao;

                    if (DateTime.TryParse(dataContratoString, out dataContratacao))
                    {
                        // A conversão foi bem-sucedida, e 'dataContratacao' contém a data inserida no TextBox.
                        Console.WriteLine("Data de contratação: " + dataContratacao.ToString("MM/dd/yyyy"));
                    }
                    else
                    {
                        // A conversão falhou, informe ao usuário que a data é inválida.
                        Console.WriteLine("Data de contratação inválida. Certifique-se de usar o formato yyyy-MM-dd.");
                    }


                    string strSql = "update Funcionarios set nome=@nome,sobrenome=@sobrenome,cpf=@cpf,cargo=@cargo,salario_base=@salario_base,data_contratacao=@dataContratacao,endereco=@endereco,telefone=@telefone,email=@email,genero=@genero,data_nascimento=@datanascimento,estado_civil=@estado_civil,numero_dependentes=@numero_dependentes,departamento=@departamento where funcionario_id=@id ";

                    cm.CommandText = strSql;
                    cm.Connection = cn;


                    cm.Parameters.Add("@nome", SqlDbType.VarChar).Value = nome;
                    cm.Parameters.Add("@sobrenome", SqlDbType.VarChar).Value = sobrenome;
                    cm.Parameters.Add("@cpf", SqlDbType.VarChar).Value = cpf;
                    cm.Parameters.Add("@cargo", SqlDbType.VarChar).Value = cargo;
                    cm.Parameters.Add("@salario_base", SqlDbType.Decimal).Value = salariosalario_base;
                    cm.Parameters.Add("@dataContratacao", SqlDbType.Date).Value = dataContratacao;
                    cm.Parameters.Add("@endereco", SqlDbType.VarChar).Value = endereco;
                    cm.Parameters.Add("@telefone", SqlDbType.VarChar).Value = telefone;
                    cm.Parameters.Add("@email", SqlDbType.VarChar).Value = email;
                    cm.Parameters.Add("@genero", SqlDbType.Char).Value = genero;
                    cm.Parameters.Add("@dataNascimento", SqlDbType.Date).Value = dataNascimento;
                    cm.Parameters.Add("@estado_civil", SqlDbType.VarChar).Value = estado_civil;
                    cm.Parameters.Add("@numero_dependentes", SqlDbType.Int).Value = numero_dependentes;
                    cm.Parameters.Add("@departamento", SqlDbType.VarChar).Value = departamento;
                    cm.Parameters.Add("@id", SqlDbType.Int).Value = id;


                    cn.Open();
                    cm.ExecuteNonQuery();
                    cm.Parameters.Clear();
                    MessageBox.Show("os dados foram alterados com sucesso !!!.", "alterção de dados concluida", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    txtNome.Focus();
                    limparCampos();
                }
                catch (Exception errro)
                {
                    MessageBox.Show(errro.Message);
                    cn.Close();
                }

                finally
                {
                    cn.Close();
                }




            }
        }


    }
}
