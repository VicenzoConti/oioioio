﻿namespace Folha_de_Pagamento
{
    partial class frmFuncionario
    {
        /// <summary> 
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Designer de Componentes

        /// <summary> 
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            lblFun = new Label();
            lblCodigo = new Label();
            lbl_cod = new Label();
            txtNome = new TextBox();
            label2 = new Label();
            txtSobreNome = new TextBox();
            label3 = new Label();
            txt_cpf = new TextBox();
            label4 = new Label();
            txt_cargo = new TextBox();
            label5 = new Label();
            txt_salario = new TextBox();
            label6 = new Label();
            txt_DataContrato = new TextBox();
            label7 = new Label();
            txtEndereco = new TextBox();
            label8 = new Label();
            txtTelefone = new TextBox();
            label9 = new Label();
            txtEmail = new TextBox();
            label10 = new Label();
            dgvfunc = new DataGridView();
            groupBox1 = new GroupBox();
            txtBusca = new TextBox();
            btnNovo = new Button();
            btnGravar = new Button();
            btnAlterar = new Button();
            btnExcluir = new Button();
            btnCancelar = new Button();
            txtGenero = new TextBox();
            label12 = new Label();
            txtDataNacimento = new TextBox();
            label13 = new Label();
            txtEstadoCivil = new TextBox();
            label14 = new Label();
            txtDependentes = new TextBox();
            label15 = new Label();
            txtDepartamento = new TextBox();
            label16 = new Label();
            label1 = new Label();
            rdbAtivo = new RadioButton();
            rdbInativo = new RadioButton();
            ((System.ComponentModel.ISupportInitialize)dgvfunc).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // lblFun
            // 
            lblFun.AutoSize = true;
            lblFun.Font = new Font("Arial Narrow", 36F, FontStyle.Bold, GraphicsUnit.Point);
            lblFun.ForeColor = Color.Indigo;
            lblFun.Location = new Point(350, 17);
            lblFun.Name = "lblFun";
            lblFun.Size = new Size(311, 69);
            lblFun.TabIndex = 0;
            lblFun.Text = "Funcionário";
            lblFun.TextAlign = ContentAlignment.MiddleCenter;
            lblFun.UseWaitCursor = true;
            // 
            // lblCodigo
            // 
            lblCodigo.AutoSize = true;
            lblCodigo.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lblCodigo.ForeColor = Color.Red;
            lblCodigo.Location = new Point(54, 87);
            lblCodigo.Name = "lblCodigo";
            lblCodigo.Size = new Size(77, 24);
            lblCodigo.TabIndex = 1;
            lblCodigo.Text = "Códogo:";
            lblCodigo.UseWaitCursor = true;
            lblCodigo.Visible = false;
            // 
            // lbl_cod
            // 
            lbl_cod.AllowDrop = true;
            lbl_cod.AutoSize = true;
            lbl_cod.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point);
            lbl_cod.ForeColor = Color.Red;
            lbl_cod.Location = new Point(127, 87);
            lbl_cod.Name = "lbl_cod";
            lbl_cod.Size = new Size(0, 24);
            lbl_cod.TabIndex = 2;
            lbl_cod.UseWaitCursor = true;
            lbl_cod.Visible = false;
            // 
            // txtNome
            // 
            txtNome.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtNome.Location = new Point(142, 121);
            txtNome.MaxLength = 50;
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(225, 30);
            txtNome.TabIndex = 6;
            txtNome.UseWaitCursor = true;
            txtNome.TextChanged += textBox2_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.Indigo;
            label2.Location = new Point(79, 127);
            label2.Name = "label2";
            label2.Size = new Size(60, 24);
            label2.TabIndex = 5;
            label2.Text = "Nome:";
            label2.UseWaitCursor = true;
            label2.Click += label2_Click;
            // 
            // txtSobreNome
            // 
            txtSobreNome.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtSobreNome.Location = new Point(142, 158);
            txtSobreNome.MaxLength = 50;
            txtSobreNome.Name = "txtSobreNome";
            txtSobreNome.Size = new Size(226, 30);
            txtSobreNome.TabIndex = 8;
            txtSobreNome.UseWaitCursor = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.Indigo;
            label3.Location = new Point(34, 164);
            label3.Name = "label3";
            label3.Size = new Size(111, 24);
            label3.TabIndex = 7;
            label3.Text = "Sobre Nome:";
            label3.UseWaitCursor = true;
            // 
            // txt_cpf
            // 
            txt_cpf.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txt_cpf.Location = new Point(142, 194);
            txt_cpf.MaxLength = 11;
            txt_cpf.Name = "txt_cpf";
            txt_cpf.Size = new Size(225, 30);
            txt_cpf.TabIndex = 10;
            txt_cpf.UseWaitCursor = true;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.Indigo;
            label4.Location = new Point(89, 200);
            label4.Name = "label4";
            label4.Size = new Size(48, 24);
            label4.TabIndex = 9;
            label4.Text = "CPF:";
            label4.UseWaitCursor = true;
            // 
            // txt_cargo
            // 
            txt_cargo.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txt_cargo.Location = new Point(142, 230);
            txt_cargo.MaxLength = 50;
            txt_cargo.Name = "txt_cargo";
            txt_cargo.Size = new Size(225, 30);
            txt_cargo.TabIndex = 12;
            txt_cargo.UseWaitCursor = true;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label5.ForeColor = Color.Indigo;
            label5.Location = new Point(77, 236);
            label5.Name = "label5";
            label5.Size = new Size(62, 24);
            label5.TabIndex = 11;
            label5.Text = "Cargo:";
            label5.UseWaitCursor = true;
            // 
            // txt_salario
            // 
            txt_salario.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txt_salario.Location = new Point(142, 266);
            txt_salario.Name = "txt_salario";
            txt_salario.Size = new Size(225, 30);
            txt_salario.TabIndex = 14;
            txt_salario.UseWaitCursor = true;
            txt_salario.TextChanged += textBox1_TextChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.Indigo;
            label6.Location = new Point(77, 272);
            label6.Name = "label6";
            label6.Size = new Size(68, 24);
            label6.TabIndex = 13;
            label6.Text = "Salario:";
            label6.UseWaitCursor = true;
            // 
            // txt_DataContrato
            // 
            txt_DataContrato.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txt_DataContrato.Location = new Point(143, 302);
            txt_DataContrato.Name = "txt_DataContrato";
            txt_DataContrato.Size = new Size(225, 30);
            txt_DataContrato.TabIndex = 16;
            txt_DataContrato.UseWaitCursor = true;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label7.ForeColor = Color.Indigo;
            label7.Location = new Point(10, 308);
            label7.Name = "label7";
            label7.Size = new Size(146, 24);
            label7.TabIndex = 15;
            label7.Text = "Data de Contrato:";
            label7.UseWaitCursor = true;
            label7.Click += label7_Click;
            // 
            // txtEndereco
            // 
            txtEndereco.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtEndereco.Location = new Point(142, 338);
            txtEndereco.MaxLength = 100;
            txtEndereco.Name = "txtEndereco";
            txtEndereco.Size = new Size(225, 30);
            txtEndereco.TabIndex = 18;
            txtEndereco.UseWaitCursor = true;
            txtEndereco.TextChanged += textBox1_TextChanged_1;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label8.ForeColor = Color.Indigo;
            label8.Location = new Point(60, 344);
            label8.Name = "label8";
            label8.Size = new Size(89, 24);
            label8.TabIndex = 17;
            label8.Text = "Endereço:";
            label8.UseWaitCursor = true;
            label8.Click += label8_Click;
            // 
            // txtTelefone
            // 
            txtTelefone.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtTelefone.Location = new Point(142, 374);
            txtTelefone.MaxLength = 20;
            txtTelefone.Name = "txtTelefone";
            txtTelefone.Size = new Size(225, 30);
            txtTelefone.TabIndex = 20;
            txtTelefone.UseWaitCursor = true;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label9.ForeColor = Color.Indigo;
            label9.Location = new Point(66, 380);
            label9.Name = "label9";
            label9.Size = new Size(81, 24);
            label9.TabIndex = 19;
            label9.Text = "Telefone:";
            label9.UseWaitCursor = true;
            // 
            // txtEmail
            // 
            txtEmail.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtEmail.Location = new Point(142, 410);
            txtEmail.MaxLength = 50;
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(225, 30);
            txtEmail.TabIndex = 22;
            txtEmail.UseWaitCursor = true;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label10.ForeColor = Color.Indigo;
            label10.Location = new Point(87, 419);
            label10.Name = "label10";
            label10.Size = new Size(57, 24);
            label10.TabIndex = 21;
            label10.Text = "Email:";
            label10.UseWaitCursor = true;
            label10.Click += label10_Click;
            // 
            // dgvfunc
            // 
            dgvfunc.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvfunc.Location = new Point(372, 206);
            dgvfunc.MultiSelect = false;
            dgvfunc.Name = "dgvfunc";
            dgvfunc.RowHeadersWidth = 51;
            dgvfunc.RowTemplate.Height = 29;
            dgvfunc.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvfunc.Size = new Size(613, 485);
            dgvfunc.TabIndex = 25;
            dgvfunc.UseWaitCursor = true;
            dgvfunc.CellMouseDoubleClick += dgvfunc_CellMouseDoubleClick;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(txtBusca);
            groupBox1.Font = new Font("Arial Narrow", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            groupBox1.Location = new Point(372, 106);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(474, 94);
            groupBox1.TabIndex = 26;
            groupBox1.TabStop = false;
            groupBox1.Text = "Pesquisa Por Funcionáro";
            groupBox1.UseWaitCursor = true;
            // 
            // txtBusca
            // 
            txtBusca.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtBusca.Location = new Point(0, 41);
            txtBusca.MaxLength = 50;
            txtBusca.Name = "txtBusca";
            txtBusca.Size = new Size(468, 30);
            txtBusca.TabIndex = 7;
            txtBusca.UseWaitCursor = true;
            txtBusca.TextChanged += txtBusca_TextChanged;
            // 
            // btnNovo
            // 
            btnNovo.Font = new Font("Arial Narrow", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            btnNovo.ForeColor = Color.Indigo;
            btnNovo.Image = Properties.Resources.adicionar_documento;
            btnNovo.ImageAlign = ContentAlignment.MiddleLeft;
            btnNovo.Location = new Point(991, 172);
            btnNovo.Name = "btnNovo";
            btnNovo.Size = new Size(156, 71);
            btnNovo.TabIndex = 28;
            btnNovo.Text = "Novo";
            btnNovo.UseVisualStyleBackColor = true;
            btnNovo.UseWaitCursor = true;
            btnNovo.Click += btnNovo_Click;
            // 
            // btnGravar
            // 
            btnGravar.Font = new Font("Arial Narrow", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            btnGravar.ForeColor = Color.Indigo;
            btnGravar.Image = Properties.Resources.disco;
            btnGravar.ImageAlign = ContentAlignment.MiddleLeft;
            btnGravar.Location = new Point(991, 249);
            btnGravar.Name = "btnGravar";
            btnGravar.Size = new Size(156, 68);
            btnGravar.TabIndex = 29;
            btnGravar.Text = "Gravar";
            btnGravar.UseVisualStyleBackColor = true;
            btnGravar.UseWaitCursor = true;
            btnGravar.Click += btnGravar_Click;
            // 
            // btnAlterar
            // 
            btnAlterar.Font = new Font("Arial Narrow", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            btnAlterar.ForeColor = Color.Indigo;
            btnAlterar.Image = Properties.Resources.lapis__1_;
            btnAlterar.ImageAlign = ContentAlignment.MiddleLeft;
            btnAlterar.Location = new Point(991, 323);
            btnAlterar.Name = "btnAlterar";
            btnAlterar.Size = new Size(156, 68);
            btnAlterar.TabIndex = 30;
            btnAlterar.Text = "Alterar";
            btnAlterar.UseVisualStyleBackColor = true;
            btnAlterar.UseWaitCursor = true;
            btnAlterar.Click += btnAlterar_Click;
            // 
            // btnExcluir
            // 
            btnExcluir.Font = new Font("Arial Narrow", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            btnExcluir.ForeColor = Color.Indigo;
            btnExcluir.Image = Properties.Resources.lixo;
            btnExcluir.ImageAlign = ContentAlignment.MiddleLeft;
            btnExcluir.Location = new Point(991, 397);
            btnExcluir.Name = "btnExcluir";
            btnExcluir.Size = new Size(156, 68);
            btnExcluir.TabIndex = 31;
            btnExcluir.Text = "Remover";
            btnExcluir.UseVisualStyleBackColor = true;
            btnExcluir.UseWaitCursor = true;
            // 
            // btnCancelar
            // 
            btnCancelar.Font = new Font("Arial Narrow", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            btnCancelar.ForeColor = Color.Indigo;
            btnCancelar.Image = Properties.Resources.cruz_pequeno;
            btnCancelar.ImageAlign = ContentAlignment.MiddleLeft;
            btnCancelar.Location = new Point(991, 471);
            btnCancelar.Name = "btnCancelar";
            btnCancelar.Size = new Size(156, 68);
            btnCancelar.TabIndex = 32;
            btnCancelar.Text = "Cancelar";
            btnCancelar.UseVisualStyleBackColor = true;
            btnCancelar.UseWaitCursor = true;
            btnCancelar.Click += btnCancelar_Click;
            // 
            // txtGenero
            // 
            txtGenero.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtGenero.Location = new Point(143, 446);
            txtGenero.MaxLength = 1;
            txtGenero.Name = "txtGenero";
            txtGenero.Size = new Size(225, 30);
            txtGenero.TabIndex = 34;
            txtGenero.UseWaitCursor = true;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label12.ForeColor = Color.Indigo;
            label12.Location = new Point(74, 449);
            label12.Name = "label12";
            label12.Size = new Size(72, 24);
            label12.TabIndex = 33;
            label12.Text = "Genero:";
            label12.UseWaitCursor = true;
            // 
            // txtDataNacimento
            // 
            txtDataNacimento.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtDataNacimento.Location = new Point(143, 482);
            txtDataNacimento.MaxLength = 50;
            txtDataNacimento.Name = "txtDataNacimento";
            txtDataNacimento.Size = new Size(225, 30);
            txtDataNacimento.TabIndex = 36;
            txtDataNacimento.UseWaitCursor = true;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label13.ForeColor = Color.Indigo;
            label13.Location = new Point(1, 488);
            label13.Name = "label13";
            label13.Size = new Size(161, 24);
            label13.TabIndex = 35;
            label13.Text = "Data de Nacimento:";
            label13.UseWaitCursor = true;
            // 
            // txtEstadoCivil
            // 
            txtEstadoCivil.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtEstadoCivil.Location = new Point(142, 518);
            txtEstadoCivil.MaxLength = 50;
            txtEstadoCivil.Name = "txtEstadoCivil";
            txtEstadoCivil.Size = new Size(225, 30);
            txtEstadoCivil.TabIndex = 38;
            txtEstadoCivil.UseWaitCursor = true;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label14.ForeColor = Color.Indigo;
            label14.Location = new Point(44, 521);
            label14.Name = "label14";
            label14.Size = new Size(107, 24);
            label14.TabIndex = 37;
            label14.Text = "Estado Civil:";
            label14.UseWaitCursor = true;
            // 
            // txtDependentes
            // 
            txtDependentes.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtDependentes.Location = new Point(143, 554);
            txtDependentes.MaxLength = 2;
            txtDependentes.Name = "txtDependentes";
            txtDependentes.Size = new Size(225, 30);
            txtDependentes.TabIndex = 40;
            txtDependentes.UseWaitCursor = true;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label15.ForeColor = Color.Indigo;
            label15.Location = new Point(35, 560);
            label15.Name = "label15";
            label15.Size = new Size(117, 24);
            label15.TabIndex = 39;
            label15.Text = "Dependentes:";
            label15.UseWaitCursor = true;
            // 
            // txtDepartamento
            // 
            txtDepartamento.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point);
            txtDepartamento.Location = new Point(143, 590);
            txtDepartamento.MaxLength = 50;
            txtDepartamento.Name = "txtDepartamento";
            txtDepartamento.Size = new Size(225, 30);
            txtDepartamento.TabIndex = 42;
            txtDepartamento.UseWaitCursor = true;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label16.ForeColor = Color.Indigo;
            label16.Location = new Point(21, 596);
            label16.Name = "label16";
            label16.Size = new Size(123, 24);
            label16.TabIndex = 41;
            label16.Text = "Departamento:";
            label16.UseWaitCursor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.Indigo;
            label1.Location = new Point(80, 633);
            label1.Name = "label1";
            label1.Size = new Size(64, 24);
            label1.TabIndex = 43;
            label1.Text = "Status:";
            label1.UseWaitCursor = true;
            // 
            // rdbAtivo
            // 
            rdbAtivo.AutoSize = true;
            rdbAtivo.Checked = true;
            rdbAtivo.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point);
            rdbAtivo.ForeColor = Color.Indigo;
            rdbAtivo.Location = new Point(155, 636);
            rdbAtivo.Name = "rdbAtivo";
            rdbAtivo.Size = new Size(68, 28);
            rdbAtivo.TabIndex = 44;
            rdbAtivo.TabStop = true;
            rdbAtivo.Text = "Ativo";
            rdbAtivo.UseVisualStyleBackColor = true;
            // 
            // rdbInativo
            // 
            rdbInativo.AutoSize = true;
            rdbInativo.Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point);
            rdbInativo.ForeColor = Color.Indigo;
            rdbInativo.Location = new Point(229, 636);
            rdbInativo.Name = "rdbInativo";
            rdbInativo.Size = new Size(80, 28);
            rdbInativo.TabIndex = 45;
            rdbInativo.Text = "Inativo";
            rdbInativo.UseVisualStyleBackColor = true;
            // 
            // frmFuncionario
            // 
            AutoScaleDimensions = new SizeF(7F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(rdbInativo);
            Controls.Add(rdbAtivo);
            Controls.Add(label1);
            Controls.Add(txtDepartamento);
            Controls.Add(label16);
            Controls.Add(txtDependentes);
            Controls.Add(label15);
            Controls.Add(txtEstadoCivil);
            Controls.Add(label14);
            Controls.Add(txtDataNacimento);
            Controls.Add(label13);
            Controls.Add(txtGenero);
            Controls.Add(label12);
            Controls.Add(btnCancelar);
            Controls.Add(btnExcluir);
            Controls.Add(btnAlterar);
            Controls.Add(btnGravar);
            Controls.Add(btnNovo);
            Controls.Add(groupBox1);
            Controls.Add(dgvfunc);
            Controls.Add(txtEmail);
            Controls.Add(label10);
            Controls.Add(txtTelefone);
            Controls.Add(label9);
            Controls.Add(txtEndereco);
            Controls.Add(label8);
            Controls.Add(txt_DataContrato);
            Controls.Add(label7);
            Controls.Add(txt_salario);
            Controls.Add(label6);
            Controls.Add(txt_cargo);
            Controls.Add(label5);
            Controls.Add(txt_cpf);
            Controls.Add(label4);
            Controls.Add(txtSobreNome);
            Controls.Add(label3);
            Controls.Add(txtNome);
            Controls.Add(label2);
            Controls.Add(lbl_cod);
            Controls.Add(lblCodigo);
            Controls.Add(lblFun);
            Font = new Font("Arial Narrow", 9F, FontStyle.Regular, GraphicsUnit.Point);
            Name = "frmFuncionario";
            Size = new Size(1221, 737);
            UseWaitCursor = true;
            Load += frmFuncionario_Load;
            ((System.ComponentModel.ISupportInitialize)dgvfunc).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblFun;
        private Label lblCodigo;
        private Label lbl_cod;
        private TextBox txtNome;
        private Label label2;
        private TextBox txtSobreNome;
        private Label label3;
        private TextBox txt_cpf;
        private Label label4;
        private TextBox txt_cargo;
        private Label label5;
        private TextBox txt_salario;
        private Label label6;
        private TextBox txt_DataContrato;
        private Label label7;
        private TextBox txtEndereco;
        private Label label8;
        private TextBox txtTelefone;
        private Label label9;
        private TextBox txtEmail;
        private Label label10;
        private DataGridView dgvfunc;
        private GroupBox groupBox1;
        private TextBox txtBusca;
        private Button btnNovo;
        private Button btnGravar;
        private Button btnAlterar;
        private Button btnExcluir;
        private Button btnCancelar;
        private TextBox txtGenero;
        private Label label12;
        private TextBox txtDataNacimento;
        private Label label13;
        private TextBox txtEstadoCivil;
        private Label label14;
        private TextBox txtDependentes;
        private Label label15;
        private TextBox txtDepartamento;
        private Label label16;
        private Label label1;
        private RadioButton rdbAtivo;
        private RadioButton rdbInativo;
    }
}
